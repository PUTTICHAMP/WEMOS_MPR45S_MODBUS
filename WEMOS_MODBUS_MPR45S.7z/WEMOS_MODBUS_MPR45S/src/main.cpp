#include "REG_SDM120.h"
#include <ModbusMaster.h>
#include <ESP8266WiFi.h>
#include <MicroGear.h>
#include <Arduino.h>
#include <SPI.h>
#include <SD.h>
// #include <WiFiUdp.h>

// ********** Set Port **********

#define  KEY          D0
#define  LED          D4
#define  DIO1         D1
#define  DIO2         D2
#define  DIO3         D3
#define  ANA0         A0
#define  SDCS         D8
#define  RTS           D6    // RS485 Direction control
#define RS485Transmit    HIGH
#define RS485Receive     LOW

// ********** Set **********

// const char* ssid     = "Horizon MSI";
// const char* password = "1212312121";
// const char* ssid     = "HUAWEI_WIFI";
// const char* password = "1212312121";
// const char* ssid     = "NSTDA-D";
// const char* password = "i0t#dEsS";    // ลง mac addtrss wemos ด้วย
// const char* ssid     = "PUTTICHAMP";
// const char* password = "p9210764";

// #define APPID   "Smartmetersd120"
// #define KEY     "y7najticv0ookS3"
// #define SECRET  "iucooohlg1BYONI9EvfReNSsG"
// #define ALIAS   "sdm120"

bool SDFIRST;

String Power = "";
// test
// WiFiClient client;
// int timer_publish = 0;
// int timer_reconnect = 0;
// MicroGear microgear(client);

//String log_sd(String log);

// void onMsghandler(char *topic, uint8_t* msg, unsigned int msglen) {
//   Serial.print("Incoming message --> ");
//   msg[msglen] = '\0';
//   Serial.println((char *)msg);
// }

/* When a microgear is connected, do this */
// void onConnected(char *attribute, uint8_t* msg, unsigned int msglen) {
//   Serial.println("Connected to NETPIE...");
//   /* Set the alias of this microgear ALIAS */
//     microgear.setAlias(ALIAS);
//     timer_reconnect = 0;
//     timer_publish = 0;
//   // log_sd("Connected to NETPIE");
//   }

ModbusMaster node;
//01 04 00 00 00 02 71 3F // Test 30001
//------------------------------------------------
// Convent 32bit to float
//------------------------------------------------
float HexTofloat(uint32_t x) {
  return (*(float*)&x);
}

uint32_t FloatTohex(float x) {
  return (*(uint32_t*)&x);
}
//------------------------------------------------

void preTransmission()
{
  digitalWrite(RTS, 1);
}

void postTransmission()
{
  digitalWrite(RTS, 0);
}


float Read_Meter_float(char addr , uint16_t  REG) {
  float i = 0;
  uint8_t j, result;
  uint16_t data;
  uint32_t value = 0;
  node.begin(addr, Serial);
   node.preTransmission(preTransmission);
   node.postTransmission(postTransmission);


  result = node.readHoldingRegisters(REG, 2);
  delayMicroseconds(300);

  if (result == node.ku8MBSuccess) {

    data = node.getResponseBuffer(1);
    // Serial.println(data);
    i = data;

    // Serial.println(i);
    // Serial.println("Connec modbus Ok.");
    return i;
  } else {
    return 0;
  }
}

void GET_METER_EASTRON() {     // Update read all data
  delay(1000);                              // เคลียบัสว่าง
    for (char i = 0; i < Total_of_EASTRON ; i++){
      DATA_METER_EASTRON [i] = Read_Meter_float(ID_meter_EASTRON, Reg_addr_EASTRON[i]);//แสกนหลายตัวตามค่า ID_METER_ALL=X
      delay(5000);
      DATA_METER_EASTRON2 [i]  = Read_Meter_float(ID_meter_EASTRON, Reg_addr_EASTRON2[i]);
      delay(5000);
      DATA_METER_EASTRON3 [i] = Read_Meter_float(ID_meter_EASTRON, Reg_addr_EASTRON3[i]);
    }
}
void METER_EASTRON() {
  GET_METER_EASTRON();
  Serial.println();
  Serial.println(F("****************METER_MPR45S Phase1*******************"));
  Serial.print("Voltage = "); Serial.print(DATA_METER_EASTRON[0]/10.0f);Serial.println(" VAC");
  Serial.print("Current = "); Serial.print(DATA_METER_EASTRON[1]);Serial.println(" Amps");
  Serial.print("Active Power= "); Serial.print(DATA_METER_EASTRON[2]);Serial.println(" Watts");
  Serial.print("Power Factor = "); Serial.println(DATA_METER_EASTRON[3]);
  Serial.print("Frequency = "); Serial.print(DATA_METER_EASTRON[4]/100.0f);Serial.println(" Hz");
  Serial.print("Total Active Energy = "); Serial.print(DATA_METER_EASTRON[5]);Serial.println(" kWh");
}

void METER_EASTRON2() {
  Serial.println();
  Serial.println(F("****************METER_MPR45S Phase2*******************"));
  Serial.print("Voltage = "); Serial.print(DATA_METER_EASTRON2[0]/10.0f);Serial.println(" VAC");
  Serial.print("Current = "); Serial.print(DATA_METER_EASTRON2[1]);Serial.println(" Amps");
  Serial.print("Active Power= "); Serial.print(DATA_METER_EASTRON2[2]);Serial.println(" Watts");
  Serial.print("Power Factor = "); Serial.println(DATA_METER_EASTRON2[3]);
  Serial.print("Frequency = "); Serial.print(DATA_METER_EASTRON2[4]/100.0f);Serial.println(" Hz");
  Serial.print("Total Active Energy = "); Serial.print(DATA_METER_EASTRON2[5]);Serial.println(" kWh");
}

void METER_EASTRON3() {
  Serial.println();
  Serial.println(F("****************METER_MPR45S Phase3*******************"));
  Serial.print("Voltage = "); Serial.print(DATA_METER_EASTRON3[0]/10.0f);Serial.println(" VAC");
  Serial.print("Current = "); Serial.print(DATA_METER_EASTRON3[1]);Serial.println(" Amps");
  Serial.print("Active Power= "); Serial.print(DATA_METER_EASTRON3[2]);Serial.println(" Watts");
  Serial.print("Power Factor = "); Serial.println(DATA_METER_EASTRON3[3]);
  Serial.print("Frequency = "); Serial.print(DATA_METER_EASTRON3[4]/100.0f);Serial.println(" Hz");
  Serial.print("Total Active Energy = "); Serial.print(DATA_METER_EASTRON3[5]);Serial.println(" kWh");
}



void setup() {
  Serial.begin(2400);
  Serial.println("Starting UDP");
  Serial.print("Local port: ");

  pinMode (KEY,INPUT);
  pinMode (LED,OUTPUT);
  pinMode (DIO1,OUTPUT);
  pinMode (DIO2,OUTPUT);
  pinMode (DIO3,OUTPUT);
  pinMode (ANA0,INPUT);
  pinMode (SDCS,OUTPUT);
  pinMode (RTS,OUTPUT);
  digitalWrite(RTS, 0);
  digitalWrite (LED,HIGH);
  delay (500);
  for (int i=0;i<=1;i++) {
    digitalWrite (LED,LOW);
    delay (100);
    digitalWrite (LED,HIGH);
    delay (150);
  }

  SDFIRST = 1;

  // microgear.on(MESSAGE,onMsghandler);
  // microgear.on(CONNECTED,onConnected);

  Serial.println("Starting...");

  /* Initial WIFI, this is just a basic method to configure WIFI on ESP8266.                       */
  /* You may want to use other method that is more complicated, but provide better user experience */
   // if (WiFi.begin(ssid, password)) {
   //   while (WiFi.status() != WL_CONNECTED) {
   //    delay(500);
   //     Serial.print(".");
   //   }
   // }
   // Serial.println("WiFi connected");
   // Serial.println("IP address: ");
   // Serial.println(WiFi.localIP());

  /* Initial with KEY, SECRET and also set the ALIAS here */
   // microgear.init(KEY,SECRET,ALIAS);
  //
  // /* connect to NETPIE to a specific APPID */
   // microgear.connect(APPID);


  // Serial.println();
  // Serial.println();
  // Serial.println(F("****************RS485 RTU MPR-45S*******************"));

}

void loop() {
  // float x = Read_Meter_float(ID_meter,Reg_Volt);


  // if (microgear.connected())
  // {
  //   Serial.println("connected");
  //   microgear.loop();
  //   if (timer_publish >= 500)
  //   {
  //           Serial.println("Publish...");
  //           //METER_MITSU();
            METER_EASTRON();
            delay(500);
            METER_EASTRON2();
            delay(500);
            METER_EASTRON3();

            // Power = "";
            // Power += (DATA_METER_EASTRON[0]/10.0f);
            // Power += "/";
            // Power += DATA_METER_EASTRON[1];
            // Power += "/";
            // Power += DATA_METER_EASTRON[2];
            // Power += "/";
            // Power += DATA_METER_EASTRON[3];
            // Power += "/";
            // Power += (DATA_METER_EASTRON[4]/100.0f);
            // Power += "/";
            // Power += DATA_METER_EASTRON[5];
            //
            // Power = "";
            // Power += (DATA_METER_EASTRON2[0]/10.0f);
            // Power += "/";
            // Power += DATA_METER_EASTRON2[1];
            // Power += "/";
            // Power += DATA_METER_EASTRON2[2];
            // Power += "/";
            // Power += DATA_METER_EASTRON2[3];
            // Power += "/";
            // Power += (DATA_METER_EASTRON2[4]/100.0f);
            // Power += "/";
            // Power += DATA_METER_EASTRON2[5];
            //
            // Power = "";
            // Power += (DATA_METER_EASTRON3[0]/10.0f);
            // Power += "/";
            // Power += DATA_METER_EASTRON3[1];
            // Power += "/";
            // Power += DATA_METER_EASTRON3[2];
            // Power += "/";
            // Power += DATA_METER_EASTRON3[3];
            // Power += "/";
            // Power += (DATA_METER_EASTRON3[4]/100.0f);
            // Power += "/";
            // Power += DATA_METER_EASTRON3[5];

            // Serial.println(Power);
            // microgear.chat("sdm120/Sensor/Power", Power);
//             timer_publish = 0;
//     }
//     else
//      {
//        timer_publish += 100;
//
//      }
//   }
//   else {
//         Serial.println("connection lost, reconnect...");
//         //log_sd("internet connection lost");
//         if (timer_reconnect >= 2000) {
//             microgear.connect(APPID);
//             timer_reconnect = 0;
//
//         }
//         else timer_reconnect += 100;
//     }
//
//     delay(1000);
 }
