#include <Arduino.h>

#define ID_meter_EASTRON 0x01
#define Total_of_EASTRON 6
#define Number_of_Reg 10

#define ADDR_NUMBER  16       // จำนวน register ที่ต้องการทั้งหมด

#define Reg_Volt                0x0000      //  0.
#define Reg_Current             0x000E      //  1.
#define Reg_ActivePower         0x001A      //  2.
#define Reg_PowerFactor         0x0048     //  3.
#define Reg_Frequency           0x0018     //  4.                               //MPR45S เฟส 1
#define Reg_TotalActiveEnergy   0x0024     //  5.

#define Reg_Volt2                0x0002      //  0.
#define Reg_Current2             0x0010      //  1.
#define Reg_ActivePower2         0x001C      //  2.
#define Reg_PowerFactor2         0x004A     //  3.
#define Reg_Frequency2           0x0018     //  4.                               //MPR45S เฟส 2
#define Reg_TotalActiveEnergy2   0x0024     //  5.

#define Reg_Volt3                0x0004      //  0.
#define Reg_Current3             0x0012      //  1.
#define Reg_ActivePower3         0x001E      //  2.
#define Reg_PowerFactor3         0x004C     //  3.
#define Reg_Frequency3           0x0018     //  4.                               //MPR45S เฟส 3
#define Reg_TotalActiveEnergy3   0x0024     //  5.


uint16_t const Reg_addr_EASTRON[6] = {
  Reg_Volt,
  Reg_Current,
  Reg_ActivePower,                                                                   //MPR45S เฟส 1
  Reg_PowerFactor,
  Reg_Frequency,
  Reg_TotalActiveEnergy
};

uint16_t const Reg_addr_EASTRON2[6] = {
  Reg_Volt2,
  Reg_Current2,
  Reg_ActivePower2,
  Reg_PowerFactor2,                                                                        //MPR45S เฟส 1
  Reg_Frequency2,
  Reg_TotalActiveEnergy2
};

uint16_t const Reg_addr_EASTRON3[6] = {
  Reg_Volt3,
  Reg_Current3,
  Reg_ActivePower3,
  Reg_PowerFactor3,
  Reg_Frequency3,                                                                      //MPR45S เฟส 1
  Reg_TotalActiveEnergy3
};


float DATA_METER [Number_of_Reg] ;
float DATA_METER_EASTRON [Total_of_EASTRON];
float DATA_METER_EASTRON2 [Total_of_EASTRON];
float DATA_METER_EASTRON3 [Total_of_EASTRON];
